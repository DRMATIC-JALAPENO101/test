import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';

export default class App extends Component {
  render() {
    return (
        <View style={{marginTop:540}}>
         <Button color="000000" title='Click Me'></Button>>
        </View>
    ); 
  }
}